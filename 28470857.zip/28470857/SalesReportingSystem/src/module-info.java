/**
 * 
 */
/**
 * 
 */
module SalesReportingSystem {
    requires java.sql;
}