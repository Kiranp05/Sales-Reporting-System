package com.cts.model;

import java.sql.Date;

public class Sales {

    private int saleId;
    private int productId;
    private int customerId;
    private Date saleDate;
    private int quantity;
    private double totalAmount;

    // Constructor for creating a new sale (without saleId)
    public Sales(int productId, int customerId, String saleDate2, int quantity, double totalAmount) {
        this.productId = productId;
        this.customerId = customerId;
        this.saleDate = saleDate2;
        this.quantity = quantity;
        this.totalAmount = totalAmount;
    }

    // Constructor for retrieving an existing sale (with saleId)
    public Sales(int saleId, int productId, int customerId, Date saleDate, int quantity, double totalAmount) {
        this.saleId = saleId;
        this.productId = productId;
        this.customerId = customerId;
        this.saleDate = saleDate;
        this.quantity = quantity;
        this.totalAmount = totalAmount;
    }

    // Getters and setters
    public int getSaleId() {
        return saleId;
    }

    public void setSaleId(int saleId) {
        this.saleId = saleId;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public Date getSaleDate() {
        return saleDate;
    }

    public void setSaleDate(Date saleDate) {
        this.saleDate = saleDate;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    @Override
    public String toString() {
        return "Sales{" +
                "saleId=" + saleId +
                ", productId=" + productId +
                ", customerId=" + customerId +
                ", saleDate=" + saleDate +
                ", quantity=" + quantity +
                ", totalAmount=" + totalAmount +
                '}';
    }
}
