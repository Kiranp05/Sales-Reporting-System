package com.cts.dao;

import com.cts.exception.SalesReportingException;
import com.cts.model.Sales;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SalesDAO {

    private Connection connection;

    public SalesDAO(Connection connection) {
        this.connection = connection;
    }

    public void addSale(Sales sale) throws SalesReportingException {
        String query = "INSERT INTO Sales (product_id, customer_id, sale_date, quantity, total_amount) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, sale.getProductId());
            pstmt.setInt(2, sale.getCustomerId());
            pstmt.setDate(3, sale.getSaleDate()); // Use java.sql.Date directly
            pstmt.setInt(4, sale.getQuantity());
            pstmt.setDouble(5, sale.getTotalAmount());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new SalesReportingException("Error adding sale: " + e.getMessage(), e);
        }
    }

    public Sales getSaleById(int saleId) throws SalesReportingException {
        Sales sale = null;
        String query = "SELECT * FROM Sales WHERE sale_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, saleId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    int productId = rs.getInt("product_id");
                    int customerId = rs.getInt("customer_id");
                    Date saleDate = rs.getDate("sale_date");
                    int quantity = rs.getInt("quantity");
                    double totalAmount = rs.getDouble("total_amount");

                    sale = new Sales(saleId, productId, customerId, saleDate, quantity, totalAmount);
                }
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error retrieving sale by ID: " + e.getMessage(), e);
        }
        return sale;
    }

    public void updateSale(Sales sale) throws SalesReportingException {
        String query = "UPDATE Sales SET product_id = ?, customer_id = ?, sale_date = ?, quantity = ?, total_amount = ? WHERE sale_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, sale.getProductId());
            pstmt.setInt(2, sale.getCustomerId());
            pstmt.setDate(3, sale.getSaleDate()); // Use java.sql.Date directly
            pstmt.setInt(4, sale.getQuantity());
            pstmt.setDouble(5, sale.getTotalAmount());
            pstmt.setInt(6, sale.getSaleId());
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SalesReportingException("No sale found with ID " + sale.getSaleId());
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error updating sale: " + e.getMessage(), e);
        }
    }

    public void deleteSale(int saleId) throws SalesReportingException {
        String query = "DELETE FROM Sales WHERE sale_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, saleId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SalesReportingException("No sale found with ID " + saleId);
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error deleting sale: " + e.getMessage(), e);
        }
    }

    public List<Sales> getAllSales() throws SalesReportingException {
        List<Sales> sales = new ArrayList<>();
        String query = "SELECT * FROM Sales";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int saleId = rs.getInt("sale_id");
                int productId = rs.getInt("product_id");
                int customerId = rs.getInt("customer_id");
                Date saleDate = rs.getDate("sale_date");
                int quantity = rs.getInt("quantity");
                double totalAmount = rs.getDouble("total_amount");

                Sales sale = new Sales(saleId, productId, customerId, saleDate, quantity, totalAmount);
                sales.add(sale);
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error retrieving all sales: " + e.getMessage(), e);
        }
        return sales;
    }
}
