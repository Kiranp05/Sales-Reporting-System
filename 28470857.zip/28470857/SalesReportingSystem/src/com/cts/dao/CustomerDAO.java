package com.cts.dao;

import com.cts.exception.SalesReportingException;
import com.cts.model.Customer;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {

    private Connection connection;

    public CustomerDAO(Connection connection) {
        this.connection = connection;
    }

    // Method to add a new customer to the database
    public void addCustomer(Customer customer) throws SalesReportingException {
        String query = "INSERT INTO Customer (name, email, phone, address) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getPhone());
            pstmt.setString(4, customer.getAddress());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            throw new SalesReportingException("Error adding customer: " + e.getMessage(), e);
        }
    }

    // Method to retrieve a customer by ID
    public Customer getCustomerById(int customerId) throws SalesReportingException {
        String query = "SELECT * FROM Customer WHERE customer_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    String name = rs.getString("name");
                    String email = rs.getString("email");
                    String phone = rs.getString("phone");
                    String address = rs.getString("address");

                    return new Customer(customerId, name, email, phone, address);
                } else {
                    throw new SalesReportingException("Customer with ID " + customerId + " not found.");
                }
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error retrieving customer: " + e.getMessage(), e);
        } catch (Exception e) {
            throw new SalesReportingException("Error creating Customer object: " + e.getMessage(), e);
        }
    }

    // Method to retrieve all customers from the database
    public List<Customer> getAllCustomers() throws SalesReportingException {
        List<Customer> customers = new ArrayList<>();
        String query = "SELECT * FROM Customer";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int customerId = rs.getInt("customer_id");
                String name = rs.getString("name");
                String email = rs.getString("email");
                String phone = rs.getString("phone");
                String address = rs.getString("address");

                try {
                    Customer customer = new Customer(customerId, name, email, phone, address);
                    customers.add(customer);
                } catch (Exception e) {
                    // Log and continue with next record
                    System.err.println("Error creating Customer object for ID " + customerId + ": " + e.getMessage());
                }
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error retrieving customers: " + e.getMessage(), e);
        }
        return customers;
    }

    // Method to update a customer's information in the database
    public void updateCustomer(Customer customer) throws SalesReportingException {
        String query = "UPDATE Customer SET name = ?, email = ?, phone = ?, address = ? WHERE customer_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setString(1, customer.getName());
            pstmt.setString(2, customer.getEmail());
            pstmt.setString(3, customer.getPhone());
            pstmt.setString(4, customer.getAddress());
            pstmt.setInt(5, customer.getCustomerId());
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SalesReportingException("No customer found with ID " + customer.getCustomerId());
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error updating customer: " + e.getMessage(), e);
        }
    }

    // Method to delete a customer from the database
    public void deleteCustomer(int customerId) throws SalesReportingException {
        String query = "DELETE FROM Customer WHERE customer_id = ?";
        try (PreparedStatement pstmt = connection.prepareStatement(query)) {
            pstmt.setInt(1, customerId);
            int rowsAffected = pstmt.executeUpdate();

            if (rowsAffected == 0) {
                throw new SalesReportingException("No customer found with ID " + customerId);
            }
        } catch (SQLException e) {
            throw new SalesReportingException("Error deleting customer: " + e.getMessage(), e);
        }
    }
}
